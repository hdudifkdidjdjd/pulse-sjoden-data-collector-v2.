# Pulse Sjöden Data Collector v2

Standalone, auditable PDF document collector for Svensk Travsport.

## Coverage
- Annual statistics: 2001–2019 (19 records)
- Annual reports: 2015–2025 (11 records)

Only two supplied 2018 source URLs are prefilled. Other URLs must be verified and added to `sources.csv`. No data is fabricated. Annual documents are **not** race-level betting data, and this collector does not claim to predict winners.

## Requirements
Python 3.9+ (standard library only).

## Usage
```bash
python -m collector validate
python -m collector download --output data/raw
python -m unittest discover -s tests -v
```

Downloads are limited to 30 MB per file, checked for a PDF signature and SHA-256 hashed. Review `data/raw/manifest.json` for successes and errors. PDF table extraction and statistical validation are future, separate steps.

**Pulse-CDCL-VE 3.2 remains untouched.** No code for that solver is included here.
